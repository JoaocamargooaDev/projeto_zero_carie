const express = require('express');
const router = express.Router();
const db = require('../db');

console.log('api.js carregado');

const TABLE_MAP = {
  schools: 'escolas',
  classes: 'turmas',
  children: 'criancas',
  brushing: 'escovacao'
};

router.get('/ping', (req, res) => {
  console.log('GET /api/ping chamado');
  res.json({ ok: true });
});

router.get('/:table', (req, res) => {
  const tableKey = req.params.table;
  console.log('GET dinâmico para:', tableKey);

  const table = TABLE_MAP[tableKey];
  if (!table) {
    console.log('Tabela inválida:', tableKey);
    return res.status(400).json({ error: 'Tabela inválida' });
  }

  db.query(`SELECT * FROM ${table}`, (err, result) => {
    if (err) {
      console.error('Erro SQL ao listar', table, err);
      return res.status(500).json(err);
    }
    res.json(result);
  });
});

router.post('/:table', (req, res) => {
  const tableKey = req.params.table;
  const table = TABLE_MAP[tableKey];
  if (!table) return res.status(400).json({ error: 'Tabela inválida' });

  const data = req.body;
  db.query(`INSERT INTO ${table} SET ?`, data, (err, result) => {
    if (err) {
      console.error('Erro SQL ao inserir em', table, err);
      return res.status(500).json(err);
    }
    res.json({ id: result.insertId });
  });
});

router.put('/:table/:id', (req, res) => {
  const tableKey = req.params.table;
  const table = TABLE_MAP[tableKey];
  if (!table) return res.status(400).json({ error: 'Tabela inválida' });

  const id = req.params.id;
  const data = req.body;

  db.query(`UPDATE ${table} SET ? WHERE id = ?`, [data, id], (err) => {
    if (err) {
      console.error('Erro SQL ao atualizar', table, err);
      return res.status(500).json(err);
    }
    res.json({ ok: true });
  });
});

router.delete('/:table/:id', (req, res) => {
  const tableKey = req.params.table;
  const table = TABLE_MAP[tableKey];
  if (!table) return res.status(400).json({ error: 'Tabela inválida' });

  const id = req.params.id;
  db.query(`DELETE FROM ${table} WHERE id = ?`, [id], (err) => {
    if (err) {
      console.error('Erro SQL ao deletar de', table, err);
      return res.status(500).json(err);
    }
    res.json({ ok: true });
  });
});

module.exports = router;
