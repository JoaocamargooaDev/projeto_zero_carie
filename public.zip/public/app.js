// public/app.js — versão completa e corrigida (modo API)
const MODE = 'api';
const API_BASE = '/api';

const Utils = {
  uid: () => Math.random().toString(36).slice(2) + Date.now().toString(36),
  fmtDate(d){ const dt = new Date(d); return isNaN(dt) ? '' : dt.toLocaleString(); },
  el(html){ const t=document.createElement('template'); t.innerHTML=html.trim(); return t.content.firstElementChild; },
  sortBy(k, dir='asc'){ return (a,b)=> (a[k] > b[k] ? 1 : -1) * (dir==='asc'?1:-1) }
};

// ---------------- API Client ----------------
const ApiClient = {
  async list(resource){
    const r = await fetch(`${API_BASE}/${resource}`);
    if (!r.ok) {
      const txt = await r.text().catch(()=>null);
      throw new Error(`API list ${resource} failed: ${r.status} ${r.statusText} ${txt || ''}`);
    }
    return r.json();
  },
  async create(resource, payload){
    // don't send id on create — backend must generate numeric id (AUTO_INCREMENT)
    const clone = {...payload};
    if(clone.id) delete clone.id;
    const r = await fetch(`${API_BASE}/${resource}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(clone)});
    if (!r.ok) {
      const txt = await r.text().catch(()=>null);
      throw new Error(`API create ${resource} failed: ${r.status} ${r.statusText} ${txt || ''}`);
    }
    return r.json();
  },
  async update(resource, id, patch){
    const r = await fetch(`${API_BASE}/${resource}/${id}`, {method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(patch)});
    if (!r.ok) {
      const txt = await r.text().catch(()=>null);
      throw new Error(`API update ${resource}/${id} failed: ${r.status} ${r.statusText} ${txt || ''}`);
    }
    return r.json();
  },
  async remove(resource, id){
    const r = await fetch(`${API_BASE}/${resource}/${id}`, {method:'DELETE'});
    if (!r.ok) {
      const txt = await r.text().catch(()=>null);
      throw new Error(`API delete ${resource}/${id} failed: ${r.status} ${r.statusText} ${txt || ''}`);
    }
    return r.json();
  }
};

// ---------------- Data ----------------
const Data = {
  async kpis(){
    const [schools, children, brushing] = await Promise.all([
      ApiClient.list('schools'), ApiClient.list('children'), ApiClient.list('brushing')
    ]);
    return { schools: schools.length, children: children.length, brushings: brushing.length };
  }
};

// ---------------- UI ----------------
const UI = {
  openTab(id){
    document.querySelectorAll('[id^="view-"]').forEach(sec=>sec.hidden=true);
    document.querySelector(`#view-${id}`).hidden=false;
    document.querySelectorAll('.tab').forEach(t=>t.setAttribute('aria-selected', String(t.dataset.tab===id)));
    this.refreshAll();
  },
  async refreshAll(){
    const label = document.getElementById('modeLabel');
    if(label) label.textContent = 'api';
    await KPIs.render();
    await Tables.renderSchools();
    await Tables.renderClasses();
    await Tables.renderChildren();
    await Tables.renderBrushing();
    await Forms.fillSelects();
  },
  toast(msg){
    const el = Utils.el(`<div style="position:fixed;inset:auto auto 20px 50%;transform:translateX(-50%);background:#18224a;color:white;padding:10px 14px;border-radius:12px;z-index:9999">${msg}</div>`);
    document.body.appendChild(el); setTimeout(()=>el.remove(), 2200);
  }
};

// ---------------- KPIs ----------------
const KPIs = {
  async render(){
    try{
      const k = await Data.kpis();
      const kpis = [
        {label:'Escolas', value:k.schools},
        {label:'Crianças', value:k.children},
        {label:'Escovações', value:k.brushings}
      ];
      const wrap = document.getElementById('kpis');
      if(!wrap) return;
      wrap.innerHTML = '';
      kpis.forEach(i=> wrap.appendChild(Utils.el(
        `<div class="card panel" style="min-width:140px">
           <div class="tag">${i.label}</div>
           <div style="font-size:28px;margin-top:6px">${i.value}</div>
         </div>`
      )));
    }catch(err){
      console.error('KPIs render error', err);
    }
  }
};

// ===================== TABELAS =====================
const Tables = {
  async renderSchools(){
    try{
      const q = document.getElementById('schoolSearch')?.value?.toLowerCase()||'';
      const rows = (await ApiClient.list('schools'))
        .filter(s=> `${s.name||''} ${s.city||''}`.toLowerCase().includes(q))
        .sort(Utils.sortBy('name'));
      const box = document.getElementById('schoolsTable'); if(!box) return;
      if(!rows.length){ box.innerHTML = `<div class='empty'>Nenhuma escola cadastrada.</div>`; return; }
      const table = [`<table><thead><tr><th>Nome</th><th>Cidade</th><th style='width:180px'>Ações</th></tr></thead><tbody>`];
      rows.forEach(s=>{
        table.push(`<tr>
          <td>${s.name}</td>
          <td>${s.city||''}</td>
          <td>
            <button class='btn' onclick='Forms.openSchool(${JSON.stringify(s)})'>Editar</button>
            <button class='btn danger' onclick='Actions.deleteSchool(${s.id})'>Excluir</button>
          </td>
        </tr>`);
      });
      table.push('</tbody></table>');
      box.innerHTML = table.join('');
    }catch(err){
      console.error('renderSchools error', err);
    }
  },

  async renderClasses(){
    try{
      const [classes, schools] = await Promise.all([ApiClient.list('classes'), ApiClient.list('schools')]);
      const box = document.getElementById('classesTable'); if(!box) return;
      const filter = document.getElementById('classSchoolFilter');
      if(filter) filter.innerHTML = `<option value=''>Todas</option>` + schools.map(s=>`<option value='${s.id}'>${s.name}</option>`).join('');
      const q = (document.getElementById('classSearch')?.value||'').toLowerCase();
      const f = filter?.value||'';

      const rows = classes.filter(c=>{
        const schoolName = (schools.find(s=>s.id==c.schoolId) || {}).name || '';
        return (!f || c.schoolId==f) && (`${c.name} ${schoolName}`.toLowerCase().includes(q));
      });

      if(!rows.length){ box.innerHTML = `<div class='empty'>Nenhuma turma cadastrada.</div>`; return; }
      const sMap = new Map(schools.map(s=>[s.id,s.name]));
      const table = [`<table><thead><tr><th>Turma</th><th>Escola</th><th style='width:180px'>Ações</th></tr></thead><tbody>`];
      rows.forEach(c=>{
        table.push(`<tr><td>${c.name}</td><td>${sMap.get(c.schoolId)||'—'}</td><td>
          <button class='btn' onclick='Forms.openClass(${JSON.stringify(c)})'>Editar</button>
          <button class='btn danger' onclick='Actions.deleteClass(${c.id})'>Excluir</button>
        </td></tr>`);
      });
      table.push('</tbody></table>');
      box.innerHTML = table.join('');
    }catch(err){
      console.error('renderClasses error', err);
    }
  },

  async renderChildren(){
    try{
      const [children, schools, classes] = await Promise.all([ApiClient.list('children'), ApiClient.list('schools'), ApiClient.list('classes')]);
      const box = document.getElementById('childrenTable'); if(!box) return;

      const schSel = document.getElementById('childSchoolFilter');
      const clsSel = document.getElementById('childClassFilter');
      if(schSel) schSel.innerHTML = `<option value=''>Todas</option>` + schools.map(s=>`<option value='${s.id}'>${s.name}</option>`).join('');
      if(clsSel) clsSel.innerHTML = `<option value=''>Todas</option>` + classes.map(t=>`<option value='${t.id}'>${t.name}</option>`).join('');

      const q = document.getElementById('childSearch')?.value?.toLowerCase()||'';
      const fs = schSel?.value||''; const fc = clsSel?.value||'';

      const rows = children
        .filter(c=> (`${c.name} ${c.guardian||''}`).toLowerCase().includes(q))
        .filter(c=> (!fs || c.schoolId==fs) && (!fc || c.classId==fc))
        .sort(Utils.sortBy('name'));

      if(!rows.length){ box.innerHTML = `<div class='empty'>Nenhuma criança cadastrada.</div>`; return; }
      const sMap = new Map(schools.map(s=>[s.id, s]));
      const tMap = new Map(classes.map(t=>[t.id, t]));
      const table = [`<table><thead><tr><th>Nome</th><th>Responsável</th><th>Escola</th><th>Turma</th><th>Nascimento</th><th style='width:240px'>Ações</th></tr></thead><tbody>`];
      rows.forEach(c=>{
        const s = sMap.get(c.schoolId), t = tMap.get(c.classId);
        table.push(`<tr>
          <td>${c.name}</td>
          <td>${c.guardian||'<span class="muted">—</span>'}</td>
          <td>${s?.name||'<span class="muted">—</span>'}</td>
          <td>${t?.name||'<span class="muted">—</span>'}</td>
          <td>${c.birthDate||'<span class="muted">—</span>'}</td>
          <td>
            <button class='btn' onclick='Forms.openChild(${JSON.stringify(c)})'>Editar</button>
            <button class='btn warn' onclick='Forms.quickBrush(${c.id})'>+ Escovação</button>
            <button class='btn danger' onclick='Actions.deleteChild(${c.id})'>Excluir</button>
          </td>
        </tr>`);
      });
      table.push('</tbody></table>');
      box.innerHTML = table.join('');
    }catch(err){
      console.error('renderChildren error', err);
    }
  },

  async renderBrushing(){
    try{
      const [rows, children] = await Promise.all([ApiClient.list('brushing'), ApiClient.list('children')]);
      const cMap = new Map(children.map(c=>[c.id, c]));
      const box = document.getElementById('brushingTable'); if(!box) return;
      if(!rows.length){ box.innerHTML = `<div class='empty'>Sem registros.</div>`; return; }
      const table = [`<table><thead><tr><th>Data</th><th>Criança</th><th>Supervisor</th><th>Foto</th><th>Obs.</th><th style='width:120px'>Ações</th></tr></thead><tbody>`];
      rows.sort((a,b)=> new Date(b.datetime) - new Date(a.datetime)).forEach(r=>{
        const thumb = r.photoUrl ? `<img src="${r.photoUrl}" alt="foto" style="width:42px;height:42px;border-radius:8px;object-fit:cover;border:1px solid rgba(255,255,255,.15)" />` : '<span class="muted">—</span>';
        table.push(`<tr>
          <td>${Utils.fmtDate(r.datetime)}</td>
          <td>${cMap.get(r.childId)?.name||'<span class="muted">(excluída)</span>'}</td>
          <td>${r.supervisor||'<span class="muted">—</span>'}</td>
          <td>${thumb}</td>
          <td>${r.notes||'<span class="muted">—</span>'}</td>
          <td><button class='btn danger' onclick='Actions.deleteBrushing(${r.id})'>Excluir</button></td>
        </tr>`);
      });
      table.push('</tbody></table>');
      box.innerHTML = table.join('');
    }catch(err){
      console.error('renderBrushing error', err);
    }
  }
};

// ===================== FORMS =====================
const Forms = {
  async fillSelects(){
    try{
      const [schools, children, classes] = await Promise.all([ApiClient.list('schools'), ApiClient.list('children'), ApiClient.list('classes')]);
      const childSel = document.getElementById('brushChild');
      const repSchool = document.getElementById('repSchool'); // inexistente agora
      const repClass = document.getElementById('repClass');   // inexistente agora

      if(childSel) childSel.innerHTML = children.map(c=>`<option value='${c.id}'>${c.name}</option>`).join('');
      if(repSchool) repSchool.innerHTML = `<option value=''>Todas</option>` + schools.map(s=>`<option value='${s.id}'>${s.name}</option>`).join('');
      if(repClass) repClass.innerHTML = `<option value=''>Todas</option>` + classes.map(t=>`<option value='${t.id}'>${t.name}</option>`).join('');
    }catch(err){
      console.error('fillSelects error', err);
    }
  },

  async openSchool(data){
    const isEdit = !!data;
    const dlg = Utils.el(`<div class='card panel' style='position:fixed;inset:0;display:grid;place-items:center;background:rgba(0,0,0,.5)'>
      <form class='card panel' style='min-width:340px;max-width:520px' onsubmit='return false'>
        <h2>${isEdit? 'Editar': 'Nova'} Escola</h2>
        <div class='field'><label>Nome</label><input id='f_name' required value='${data?.name||''}'/></div>
        <div class='field'><label>Cidade</label><input id='f_city' required value='${data?.city||''}'/></div>
        <div class='row' style='margin-top:12px'>
          <button class='btn' type='button' onclick='this.closest("div[style]").remove()'>Cancelar</button>
          <button class='btn primary' type='submit'>Salvar</button>
        </div>
      </form>
    </div>`);
    document.body.appendChild(dlg);
    dlg.querySelector('form').addEventListener('submit', async ()=>{
      // build payload — do NOT set id for new records
      const payload = { name: dlg.querySelector('#f_name').value.trim(), city: dlg.querySelector('#f_city').value.trim() };
      if(!payload.name || !payload.city){ alert('Preencha todos os campos.'); return; }
      try{
        if(isEdit){
          await ApiClient.update('schools', data.id, payload);
        } else {
          await ApiClient.create('schools', payload);
        }
        dlg.remove(); UI.refreshAll(); UI.toast('Escola salva.');
      }catch(err){
        console.error('save school error', err);
        alert('Erro ao salvar escola. Veja console.');
      }
    });
  },

  async openClass(data){
    const isEdit = !!data;
    // fetch schools to populate select
    const schools = await ApiClient.list('schools');
    const options = schools.map(s=>`<option value='${s.id}' ${data?.schoolId==s.id?'selected':''}>${s.name}</option>`).join('');
    const dlg = Utils.el(`<div class='card panel' style='position:fixed;inset:0;display:grid;place-items:center;background:rgba(0,0,0,.5)'>
      <form class='card panel' style='min-width:360px;max-width:640px' onsubmit='return false'>
        <h2>${isEdit? 'Editar': 'Nova'} Turma</h2>
        <div class='row'>
          <div class='field'><label>Nome</label><input id='cl_name' required value='${data?.name||''}'/></div>
          <div class='field'><label>Escola</label><select id='cl_school' required>${options}</select></div>
        </div>
        <div class='row' style='margin-top:12px'>
          <button class='btn' type='button' onclick='this.closest("div[style]").remove()'>Cancelar</button>
          <button class='btn primary' type='submit'>Salvar</button>
        </div>
      </form>
    </div>`);
    document.body.appendChild(dlg);
    dlg.querySelector('form').addEventListener('submit', async ()=>{
      const payload = { name: dlg.querySelector('#cl_name').value.trim(), schoolId: dlg.querySelector('#cl_school').value };
      if(!payload.name || !payload.schoolId){ alert('Preencha todos os campos.'); return; }
      try{
        if(isEdit){
          await ApiClient.update('classes', data.id, payload);
        } else {
          await ApiClient.create('classes', payload);
        }
        dlg.remove(); UI.refreshAll(); UI.toast('Turma salva.');
      }catch(err){
        console.error('save class error', err);
        alert('Erro ao salvar turma. Veja console.');
      }
    });
  },

  async openChild(data){
    const isEdit = !!data;
    const [schools, classes] = await Promise.all([ApiClient.list('schools'), ApiClient.list('classes')]);
    const sOpts = schools.map(s=>`<option value='${s.id}' ${data?.schoolId==s.id?'selected':''}>${s.name}</option>`).join('');
    const cOpts = [`<option value=''>—</option>`].concat(classes.map(t=>`<option value='${t.id}' ${data?.classId==t.id?'selected':''}>${t.name}</option>`)).join('');
    const dlg = Utils.el(`<div class='card panel' style='position:fixed;inset:0;display:grid;place-items:center;background:rgba(0,0,0,.5)'>
      <form class='card panel' style='min-width:360px;max-width:640px' onsubmit='return false'>
        <h2>${isEdit? 'Editar': 'Nova'} Criança</h2>
        <div class='row'>
          <div class='field'><label>Nome</label><input id='c_name' required value='${data?.name||''}'/></div>
          <div class='field'><label>Nascimento</label><input id='c_birth' type='date' value='${data?.birthDate||''}'/></div>
        </div>
        <div class='row'>
          <div class='field'><label>Responsável</label><input id='c_guardian' value='${data?.guardian||''}'/></div>
          <div class='field'><label>Escola</label><select id='c_school' required>${sOpts}</select></div>
          <div class='field'><label>Turma</label><select id='c_class'>${cOpts}</select></div>
        </div>
        <div class='row' style='margin-top:12px'>
          <button class='btn' type='button' onclick='this.closest("div[style]").remove()'>Cancelar</button>
          <button class='btn primary' type='submit'>Salvar</button>
        </div>
      </form>
    </div>`);
    document.body.appendChild(dlg);
    dlg.querySelector('form').addEventListener('submit', async ()=>{
      const payload = {
        name: dlg.querySelector('#c_name').value.trim(),
        birthDate: dlg.querySelector('#c_birth').value || null,
        guardian: dlg.querySelector('#c_guardian').value.trim() || null,
        schoolId: dlg.querySelector('#c_school').value,
        classId: dlg.querySelector('#c_class').value || null
      };
      if(!payload.name || !payload.schoolId){ alert('Preencha os campos obrigatórios.'); return; }
      try{
        if(isEdit){
          await ApiClient.update('children', data.id, payload);
        } else {
          await ApiClient.create('children', payload);
        }
        dlg.remove(); UI.refreshAll(); UI.toast('Criança salva.');
      }catch(err){
        console.error('save child error', err);
        alert('Erro ao salvar criança. Veja console.');
      }
    });
  },

  quickBrush(childId){
    const now = new Date().toISOString().slice(0,16);
    const el = document.getElementById('brushDate');
    if(el) el.value = now;
    const sel = document.getElementById('brushChild');
    if(sel) sel.value = childId;
    UI.openTab('escovacao');
  }
};

// ===================== ACTIONS =====================
const Actions = {
  async deleteSchool(id){
    try{
      const children = await ApiClient.list('children');
      if(children.some(c=>c.schoolId==id)){ alert('Não é possível excluir: há crianças vinculadas.'); return; }
      if(confirm('Excluir esta escola?')){
        await ApiClient.remove('schools', id);
        UI.refreshAll(); UI.toast('Escola excluída.');
      }
    }catch(err){
      console.error('deleteSchool error', err);
      alert('Erro ao excluir escola. Veja console.');
    }
  },
  async deleteClass(id){
    try{
      const children = await ApiClient.list('children');
      if(children.some(c=>c.classId==id)){ alert('Não é possível excluir: há crianças vinculadas.'); return; }
      if(confirm('Excluir esta turma?')){
        await ApiClient.remove('classes', id);
        UI.refreshAll(); UI.toast('Turma excluída.');
      }
    }catch(err){
      console.error('deleteClass error', err);
      alert('Erro ao excluir turma. Veja console.');
    }
  },
  async deleteChild(id){
    try{
      if(confirm('Excluir esta criança?')){
        await ApiClient.remove('children', id);
        UI.refreshAll(); UI.toast('Criança excluída.');
      }
    }catch(err){
      console.error('deleteChild error', err);
      alert('Erro ao excluir criança. Veja console.');
    }
  },
  async addBrushing(e){
    e.preventDefault();
    try{
      const file = document.getElementById('brushPhoto')?.files?.[0];
      let photoDataUrl = '';
      if (file) {
        const buf = await file.arrayBuffer();
        const base64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
        photoDataUrl = `data:${file.type};base64,${base64}`;
      }
      const payload = {
        childId: document.getElementById('brushChild').value,
        datetime: new Date(document.getElementById('brushDate').value).toISOString(),
        notes: document.getElementById('brushNotes').value.trim() || null,
        supervisor: document.getElementById('brushSupervisor').value.trim() || null,
        photoUrl: photoDataUrl || null
      };
      if(!payload.childId || !payload.datetime){ alert('Selecione a criança e a data/hora.'); return; }
      await ApiClient.create('brushing', payload);
      e.target.reset(); UI.refreshAll(); UI.toast('Registro salvo (+10 pts).');
    }catch(err){
      console.error('addBrushing error', err);
      alert('Erro ao salvar registro. Veja console.');
    }
  },
  async deleteBrushing(id){
    try{
      if(confirm('Excluir este registro de escovação?')){
        await ApiClient.remove('brushing', id);
        UI.refreshAll(); UI.toast('Registro excluído.');
      }
    }catch(err){
      console.error('deleteBrushing error', err);
      alert('Erro ao excluir registro. Veja console.');
    }
  }
};

// ----------------- Init -----------------
document.querySelectorAll('.tab').forEach(t=> t.addEventListener('click', ()=> UI.openTab(t.dataset.tab)) );
const brushDate = document.getElementById('brushDate');
if(brushDate) brushDate.value = new Date().toISOString().slice(0,16);
UI.refreshAll();
